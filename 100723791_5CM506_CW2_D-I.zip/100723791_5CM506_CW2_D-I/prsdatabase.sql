-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2025 at 12:41 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prsdatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--

CREATE TABLE `audit_logs` (
  `log_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action` varchar(255) NOT NULL,
  `entity_affected` varchar(100) DEFAULT NULL,
  `record_id` int(11) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `documents`
--

CREATE TABLE `documents` (
  `document_id` int(11) NOT NULL,
  `file_type` varchar(50) NOT NULL,
  `file_path` text NOT NULL,
  `uploaded_by` int(11) NOT NULL,
  `related_record_id` int(11) DEFAULT NULL,
  `upload_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `encryption_keys`
--

CREATE TABLE `encryption_keys` (
  `key_id` int(11) NOT NULL,
  `key_type` varchar(50) NOT NULL,
  `key_value` text NOT NULL,
  `owner` varchar(50) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `role_id` int(11) NOT NULL,
  `role_name` varchar(50) NOT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`role_id`, `role_name`, `description`) VALUES
(1, 'Government Official', 'Can monitor vaccination and supply chain'),
(2, 'Merchant', 'Can manage pandemic-related supplies'),
(3, 'Public Member', 'Can track vaccination records');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `national_id` varchar(50) NOT NULL,
  `prs_id` varchar(50) NOT NULL,
  `role_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `full_name`, `email`, `password_hash`, `phone`, `national_id`, `prs_id`, `role_id`, `created_at`) VALUES
(1, 'Gabriela Santos', 'gabriela@customs.org', 'ff7c56fe6c4e64e2e9788d3e8a998142e9c69703b1ce88c860653f200cabf896', '+1445566778', 'CUS45678', 'PRS007', 3, '2025-04-16 14:07:23'),
(2, 'Hiroshi Tanaka', 'hiroshi@import.com', '3a7683f754d55ca5cc51af7ede4633a389102cc08d1924cae95ae5d094a367c7', '+1223344556', 'IMP67890', 'PRS008', 2, '2025-04-16 14:07:23'),
(3, 'Isabel Martinez', 'isabel@gov.tech', 'd3959f966dee9901106e5868bbc7a24ae05db399f9d9b4f7c0206d7b7838e295', '+1667788990', 'GOV78901', 'PRS009', 1, '2025-04-16 14:07:23'),
(4, 'James Wilson', 'james@export.org', '4f829c14374f8f328e4bda8d7cbb73e27d97eb6b14c80916f9fc25e44938a1a3', '+1889900112', 'EXP12345', 'PRS010', 3, '2025-04-16 14:07:23'),
(9, 'Test User', 'testing@example.com', '$2y$10$n292zC9Ic7/ffwwweDeRtOSxrCAZayrg5uHGL7mgJY.yMY8KvDBC2', NULL, '', '', 1, '2025-04-16 19:30:27'),
(26, 'Test2 omg', 'test@again.com', '$2y$10$paKWaggyBbeQHt42ry9ZveO.oWeE87NE1pfGWd16rUzwbv2NTqPpa', '555-123-4567', 'NID-2023-0001', 'PRS-2023-0001', 1, '2025-05-04 17:21:10'),
(27, 'qw', 'qw@example.com', '$2y$10$0tQUvtL691H4IPapZCEeAuyLVlSTmj6vLDpMJSkH7e552sGytww7G', '1234567899876543', 'qw na id', 'qw prs id', 3, '2025-05-05 14:03:49'),
(32, 'er', 'er@example.com', '$2y$10$5dJuQbzewAac8WEhGupBbObU/qoG/PC6EHGSOw6VuNPTe/SY4C.OO', '87698769876', 'er na id', 'er prs id', 3, '2025-05-05 14:34:09'),
(34, 'FHIR Import', 'import@fhir.local', '$2y$10$qDrECXBjK8aHVdv5dTV1J.SbR2EC3w9z2sVgQVTAzA9OJUpqV1TG.', NULL, '9000000009', 'PRS-1747074090', 3, '2025-05-12 18:21:30'),
(35, 'kon koll', 'kk@example.com', '$2y$10$ayNjFfBIQuWUjp7EXdRix..2ZW/QkbYFzPR/sovXyHMXiwbip1cvy', '98723641982746', 'kk8765876', 'PRS-id-567', 3, '2025-05-12 18:29:44'),
(36, 'George Ion', 'geoion@example.com', '$2y$10$gtXrB29wR3WgE7A4t5JLV.z4xhaXJ8heyBU/JxDUwulHNOJ.8Xsty', '6259654', 'GG12345', 'PRS-2025-611865', 3, '2025-05-15 18:12:24'),
(37, 'Lam Gro', 'LG@example.com', '$2y$10$u3XS8GJk2q7ffMPBAO6Vj.F6S.5KG.0iWYJMLbfVng.3AzcGasNDe', '654987', 'UK123456', 'PRS-2025-599425', 3, '2025-05-15 20:40:42'),
(38, 'Dimitri Kingovic', 'dk@example.com', '$2y$10$wdj8q2XiLUAryBSF7iIQA.xgIHUeBpOb4vkm1ly35m3ETLpIYpI9K', '65465465465', 'SB123456', 'PRS-2025-509144', 3, '2025-05-16 11:06:47'),
(39, 'Pablo Kounoupi', 'pk@example.com', '$2y$10$uqZhlihP0HYKfhnimtoF0ec1RsJTVeNkOXX2ztVNqE59gzhAulELi', '687987987', 'AB696969', 'PRS-2025-176336', 3, '2025-05-16 11:17:40'),
(40, 'Kristo Simovic', 'ks@example.com', '$2y$10$2A/y4Sbl02G5lVYI8csPN.de9Ox.6krfZa8VIq81dYznglKy9Kxm.', '789456789', 'CZ34532', 'PRS-2025-980611', 3, '2025-05-16 11:30:32'),
(41, 'Alice Gib', 'ag@example.com', '$2y$10$b6niAByUl7cD8LRAb9jMUOxFIBsbqWrMDiBfVOVJHHd0X6k1oYwru', '789456123', 'FR12345', 'PRS-2025-949179', 3, '2025-05-20 10:30:01'),
(43, 'Denis Gus', 'dg@example.com', '$2y$10$H5m16j1BwzproSyodDW2de8w.r/bNsq.yJNJoQTQ.M232EmxCXoPO', '7896546543', 'RS123456', 'PRS-2025-282854', 3, '2025-05-21 14:05:18'),
(46, 'Charlie Tester', 'charlie@example.com', '$2y$10$DvI8rPhaIliBKSf.SFnD1OKZI6zgM2Ze1EymAi0r8X1fO.cuqcupO', '+1234567890', 'NID998877', 'PRS998', 3, '2025-05-24 21:15:37');

-- --------------------------------------------------------

--
-- Table structure for table `vaccination_records`
--

CREATE TABLE `vaccination_records` (
  `record_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `vaccine_name` varchar(255) NOT NULL,
  `date_administered` date NOT NULL,
  `dose_number` int(11) NOT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `lot_number` varchar(50) DEFAULT NULL,
  `expiration_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vaccination_records`
--

INSERT INTO `vaccination_records` (`record_id`, `user_id`, `vaccine_name`, `date_administered`, `dose_number`, `provider`, `lot_number`, `expiration_date`, `created_at`) VALUES
(1, 1, 'COVID-19 Vaccine AstraZeneca', '2023-01-10', 1, 'City Health Clinic', 'AZ-12345', '2023-12-31', '2025-04-16 14:14:29'),
(2, 2, 'COVID-19 Vaccine AstraZeneca', '2023-02-05', 1, 'City Health Clinic', 'AZ-34567', '2023-12-31', '2025-04-16 14:14:29'),
(3, 3, 'COVID-19 Vaccine AstraZeneca', '2023-03-12', 1, 'City Health Clinic', 'AZ-34568', '2023-12-31', '2025-04-16 14:14:29'),
(4, 4, 'Pfizer-BioNTech COVID-19', '2023-01-25', 1, 'City Health Clinic', 'PF-67890', '2023-11-30', '2025-04-16 14:14:29'),
(5, 34, 'COVID-19 Vaccine AstraZeneca (NHS -Immunization-FHIR-JSON)', '2020-12-10', 1, 'TEST-SITE', 'R04X', '2021-04-29', '2025-05-12 18:21:30'),
(6, 34, 'COVID-19 Vaccine AstraZeneca (NHS -Immunization-FHIR-JSON)', '2020-12-31', 1, 'TEST-SITE', 'R04X', '2021-04-29', '2025-05-12 18:21:30'),
(7, 35, 'COVID-19 Vaccine AstraZeneca', '2020-05-01', 1, 'City Health Clinic', 'AB-23451', '2021-10-30', '2025-05-15 17:31:27'),
(8, 36, 'COVID-19 Vaccine AstraZeneca', '2024-08-14', 2, 'City Health Clinic', 'AB-23459', '2025-09-04', '2025-05-15 18:23:56'),
(9, 36, 'Pfizer-BioNTech COVID-19', '2025-03-04', 2, 'City Health Clinic', 'AB-23452', '2025-08-08', '2025-05-15 20:23:04'),
(11, 1, 'Moderna COVID-19 Vaccine', '2024-01-15', 2, 'City Health Clinic', 'AT-98765', '2026-10-16', '2025-05-15 20:34:34'),
(12, 36, 'Pfizer-BioNTech COVID-19', '2025-03-04', 3, 'City Health Clinic', 'AB-98767', '2025-07-18', '2025-05-15 20:36:42'),
(13, 37, 'Johnson & Johnson COVID-19 Vaccine', '2025-01-01', 1, 'City Health Clinic', 'AD-98765', '2025-07-03', '2025-05-15 20:41:43'),
(14, 37, 'Johnson & Johnson COVID-19 Vaccine', '2025-01-01', 2, 'City Health Clinic', 'AF-98764', '2025-05-27', '2025-05-15 20:42:22'),
(16, 2, 'Sinovac COVID-19 Vaccine', '2025-05-01', 2, 'City Health Clinic', 'CB-23459', '2025-08-22', '2025-05-15 21:00:07'),
(17, 38, 'Pfizer-BioNTech COVID-19', '2025-01-01', 1, 'Dafni', 'DB-98765', '2025-10-31', '2025-05-16 11:08:57'),
(18, 39, 'Moderna COVID-19 Vaccine', '2025-01-02', 1, 'Kifis', 'TT-787878', '2025-08-27', '2025-05-16 11:20:08'),
(19, 40, 'Pfizer-BioNTech COVID-19', '2025-01-03', 1, 'Tzia', 'IF-98475', '2025-10-31', '2025-05-16 11:33:34'),
(20, 41, 'Johnson & Johnson COVID-19 Vaccine', '2025-05-12', 1, 'City Health Clinic', 'AF-54372', '2025-05-30', '2025-05-20 10:32:10'),
(21, 43, 'Sputnik V COVID-19 Vaccine', '2024-11-12', 1, 'City Health Clinic', 'RR-98765', '2025-07-23', '2025-05-21 14:07:03'),
(22, 1, 'Pfizer-BioNTech', '2025-05-20', 2, 'Community Health Center', 'PFZ20250520', '2026-05-20', '2025-05-24 22:35:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `documents`
--
ALTER TABLE `documents`
  ADD PRIMARY KEY (`document_id`),
  ADD KEY `uploaded_by` (`uploaded_by`),
  ADD KEY `related_record_id` (`related_record_id`);

--
-- Indexes for table `encryption_keys`
--
ALTER TABLE `encryption_keys`
  ADD PRIMARY KEY (`key_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`role_id`),
  ADD UNIQUE KEY `role_name` (`role_name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `national_id` (`national_id`),
  ADD UNIQUE KEY `prs_id` (`prs_id`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `vaccination_records`
--
ALTER TABLE `vaccination_records`
  ADD PRIMARY KEY (`record_id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `audit_logs`
--
ALTER TABLE `audit_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `documents`
--
ALTER TABLE `documents`
  MODIFY `document_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `encryption_keys`
--
ALTER TABLE `encryption_keys`
  MODIFY `key_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `vaccination_records`
--
ALTER TABLE `vaccination_records`
  MODIFY `record_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `documents`
--
ALTER TABLE `documents`
  ADD CONSTRAINT `documents_ibfk_1` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `documents_ibfk_2` FOREIGN KEY (`related_record_id`) REFERENCES `vaccination_records` (`record_id`) ON DELETE SET NULL;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE;

--
-- Constraints for table `vaccination_records`
--
ALTER TABLE `vaccination_records`
  ADD CONSTRAINT `vaccination_records_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
